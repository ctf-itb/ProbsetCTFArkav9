#include <array>
#include <climits>
#include <cstdio>
#include <iostream>
#include <limits>
#include <string>
#include <thread>
#include <vector>

#define ARRAY_SIZE 100
#define MAX_WORKERS 4

auto main() -> int
{
    std::string command{};
    std::array<long, 100> array{};
    std::vector<std::thread> threads{};
    int index;
    long value;

    auto store = [&] {
        if (index >= ARRAY_SIZE || index < 0)
        {
            std::cout << "invalid index" << std::endl;
            return;
        }
        std::cout << "array[" << index << "] = " << (array[index] = value) << std::endl;
    };

    auto retrieve = [&] {
        if (index >= ARRAY_SIZE || index < 0)
        {
            std::cout << "invalid index" << std::endl;
            return;
        }
        std::cout << "array[" << index << "] = " << array[index] << std::endl;
    };

    while (true)
    {
        std::cin >> command;
        if (command == "store")
        {
            std::cin >> index >> value;
            threads.emplace_back(store);
        }
        else if (command == "retrieve")
        {
            std::cin >> index;
            threads.emplace_back(retrieve);
        }
        else if (command == "exit")
        {
            break;
        }
        else
        {
            std::cout << "unknown command" << std::endl;
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }

        if (threads.size() >= MAX_WORKERS)
        {
            for (auto &t : threads)
            {
                if (t.joinable())
                    t.join();
            }
            threads.clear();
        }
    }

    for (auto &t : threads)
    {
        if (t.joinable())
            t.join();
    }
    return 0;
}
