#include <array>
#include <atomic>
#include <climits>
#include <cstdio>
#include <iostream>
#include <limits>
#include <string>
#include <thread>
#include <vector>

#define ARRAY_SIZE 100
#define MAX_WORKERS 4

auto main() -> int
{
    std::string command{};
    std::array<long, ARRAY_SIZE> array{};
    std::vector<std::thread> threads{};

    // prevent race condition
    std::atomic_int index{};
    std::atomic_long value{};

    auto store = [&] {
        if (index >= ARRAY_SIZE || index < 0)
        {
            std::cout << "invalid index" << '\n';
            return;
        }
        std::cout << "array[" << index << "] = " << (array[index] = value) << '\n';
    };

    auto retrieve = [&] {
        if (index >= ARRAY_SIZE || index < 0)
        {
            std::cout << "invalid index" << '\n';
            return;
        }
        std::cout << "array[" << index << "] = " << array[index] << '\n';
    };

    while (true)
    {
        std::cin >> command;
        if (command == "store")
        {
            int tmp_index;
            long tmp_value;
            std::cin >> tmp_index >> tmp_value;
            index.store(tmp_index);
            value.store(tmp_value);
            threads.emplace_back(store);
        }
        else if (command == "retrieve")
        {
            int tmp_index;
            std::cin >> tmp_index;
            index.store(tmp_index);
            threads.emplace_back(retrieve);
        }
        else if (command == "exit")
        {
            break;
        }
        else
        {
            std::cout << "unknown command" << std::endl;
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }

        if (threads.size() >= MAX_WORKERS)
        {
            for (auto &t : threads)
            {
                if (t.joinable())
                    t.join();
            }
            threads.clear();
        }
    }

    for (auto &t : threads)
    {
        if (t.joinable())
            t.join();
    }
    return 0;
}
