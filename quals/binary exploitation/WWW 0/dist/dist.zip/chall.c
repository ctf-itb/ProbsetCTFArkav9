#include <stdio.h>
#include <stdlib.h>

void init()
{
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);
}

void gift()
{
    char buf[1024] = {0};
    scanf(" %32[^$n\n]", buf);
    printf(buf);
    putchar('\n');
}

int main()
{
    init();
    gift();
    long long *ptr;
    printf("Where: ");
    scanf("%p", &ptr);
    printf("What: ");
    scanf("%lli", ptr);
    exit(0);
}
