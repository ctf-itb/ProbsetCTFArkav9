import express from 'express'
import crypto from 'crypto';
import fs from 'fs'

const app = express();
app.use(express.static('static'));
const port = 8020;

const index = fs.readFileSync("./html/index.html").toString();

app.get('/', function(req, res){
	const CLIENT_NONCE = crypto.randomBytes(16).toString('base64');
	const filter = req.query.filterClassifiedInfo || "";

	if (filter.length > 222) {
		res.status(400).send("Filter is too long");
		return;
	}

	// List banned words
	const bannedWords = ["http", "background", "tar"]

	// Check banned words
	for (const word of bannedWords) {
		if (filter.includes(word)) {
			res.status(400).send("Filter contains banned words");
			return;
		}
	}
	
	res.setHeader("Content-Type", "text/html; charset=utf-8");
	res.send(index.replace(/{{nonce}}/g, CLIENT_NONCE).replace(/{{filter}}/g, filter));
});

app.listen(port, async () => {
    console.log(`[*] Webapp Listening on port ${port}`)
});